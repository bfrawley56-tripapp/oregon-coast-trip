"use client";

import { useMemo, useState } from "react";
import "./full-trip.css";

type Tab = "home" | "itinerary" | "coast" | "packing" | "safety";

const links = {
  tripcheck: "https://www.tripcheck.com/",
  id511: "https://511.idaho.gov/",
  wyroad: "https://www.wyoroad.info/",
  airnow: "https://www.airnow.gov/",
  noaa: "https://www.weather.gov/",
  fires: "https://centraloregonfire.org/large-wildfire-map/",
  evacuations: "https://wildfire.oregon.gov/Pages/evacuations.aspx",
  smoke: "https://www.oregonsmoke.org/",
  motolodge: "https://www.motolodge.com/",
  hoodHotel: "https://hoodriverhotel.com/",
  shoshone: "https://www.tfid.org/309/Shoshone-Falls",
  pendleton: "https://www.travelpendleton.com/",
  walla: "https://wallawalla.org/",
  hood: "https://visithoodriver.com/",
  fogarty: "https://stateparks.oregon.gov/index.cfm?do=park.profile&parkId=157",
  gleneden: "https://stateparks.oregon.gov/index.cfm?do=park.profile&parkId=159",
  punchbowl: "https://stateparks.oregon.gov/index.cfm?do=park.profile&parkId=156",
  boiler: "https://stateparks.oregon.gov/index.cfm?do=park.profile&parkId=152",
  horn: "https://www.thehorn.pub/",
  tidal: "https://www.tidalraves.com/",
  pelican: "https://pelicanbrewing.com/pubs/siletz-bay/",
};

const days = [
  {date:"Thu Jul 23",tone:"mountain",place:"Ogden, Utah",stay:"Ogden lodging · booked",drive:"≈ 8 hr",plan:"Denver → Wyoming I-80 → Ogden",logic:"PTO",note:"Long first travel day. Use Wyoming stops for Manny, fuel and scenery."},
  {date:"Fri Jul 24",tone:"desert",place:"Pendleton, Oregon",stay:"MotoLodge · BOOKED",drive:"7½–8 hr",plan:"Ogden → Shoshone Falls → Pendleton",logic:"PTO",note:"One major scenic stop, then continue west. Mountain-to-Pacific time change returns one clock hour."},
  {date:"Sat Jul 25",tone:"gorge",place:"Hood River, Oregon",stay:"Hood River Hotel · BOOKED",drive:"2–2½ hr direct · ≈4 hr via Walla Walla",plan:"Pendleton → optional Walla Walla → Hood River",logic:"Weekend",note:"Walla Walla is optional. Skip it for heat, smoke or more time along the Gorge."},
  {date:"Sun Jul 26",tone:"coast",place:"Depoe Bay, Oregon",stay:"Coastal rental · BOOKED",drive:"3½–4½ hr",plan:"Hood River → Willamette Valley → Depoe Bay",logic:"Weekend",note:"Morning Gorge walk; flexible wine-country or picnic stop. Rental check-in at 4:00 is not a deadline."},
  {date:"Mon Jul 27",tone:"coast",place:"Depoe Bay",stay:"Coastal rental",drive:"Local · under 1 hr",plan:"Morning beach → remote work → after-work coast walk",logic:"6–8 hr work · local time",note:"Protect the work block. Keep both outings short and nearby."},
  {date:"Tue Jul 28",tone:"coast",place:"Depoe Bay",stay:"Coastal rental",drive:"Local · under 1 hr",plan:"Different morning beach → remote work → sunset option",logic:"6–8 hr work · local time",note:"Second protected workday; choose activities based on wind and tides."},
  {date:"Wed Jul 29",tone:"coast",place:"Central Oregon Coast",stay:"Coastal rental",drive:"1–2 hr flex",plan:"Full coast day",logic:"PTO",note:"Best-weather day for a longer beach, hike, Newport or Lincoln City outing."},
  {date:"Thu Jul 30",tone:"wine",place:"Yamhill, Oregon",stay:"Jake & Andrea · confirmed",drive:"2½–4 hr with stops",plan:"11:00 checkout → coast/valley meander → Yamhill",logic:"PTO",note:"Let conditions determine the inland route and stops."},
  {date:"Fri Jul 31",tone:"wine",place:"Yamhill",stay:"Jake & Andrea",drive:"Local",plan:"Visit with Jake & Andrea",logic:"PTO",note:"Local planning led by Jake and Andrea."},
  {date:"Sat Aug 1",tone:"wine",place:"Yamhill",stay:"Jake & Andrea",drive:"Local",plan:"Visit / local day",logic:"Weekend",note:"Keep this flexible."},
  {date:"Sun Aug 2",tone:"return",place:"Return corridor",stay:"Return lodging · BOOKED",drive:"Reservation-dependent",plan:"Leave Yamhill in the morning",logic:"Weekend",note:"Use weather, smoke and energy to pace the return."},
  {date:"Mon Aug 3",tone:"return",place:"Denver",stay:"Home",drive:"Final drive",plan:"Return to Denver",logic:"PTO",note:"Final drive home; normal work resumes Tuesday."},
];

const packing = {
  "Manny": ["Leash + backup leash/harness","Food, treats and medications","Collapsible bowl + extra water","Poop bags","Towel and wipes","Bed or familiar blanket","Vaccination record/photo","Paw protection / heat supplies","Cooling towel or mat","Long-lasting hotel chew"],
  "Work setup": ["Laptop + charger","Mouse and headphones","Mobile hotspot tested","Extension cord / power strip","Calendar work blocks for Jul 27–28"],
  "Road trip": ["Reservation confirmations saved offline","Offline maps and hotel phone numbers","Car registration and insurance","Roadside-assistance information","Tire pressure and fluids checked","Emergency kit","Reusable water bottles","Picnic blanket / camp chairs"],
  "Coast": ["Light rain shell","Warm layer","Beach towels","Trail shoes","Binoculars","Sunscreen","Small cooler","Tide-table shortcut saved"],
};

const stopSuggestions = [
  {name:"Green River, WY",lat:41.5291,lon:-109.4665,type:"Dog walk · fuel",detail:"Greenbelt or riverside stretch before continuing west."},
  {name:"Bear River State Park",lat:41.2708,lon:-110.9647,type:"Dog walk · picnic",detail:"Convenient I-80 green space near Evanston; leash Manny."},
  {name:"Shoshone Falls",lat:42.5937,lon:-114.4006,type:"Major nature stop",detail:"Viewpoint and paved walking; confirm heat and park hours."},
  {name:"Baker City",lat:44.7749,lon:-117.8344,type:"Cute town · food · fuel",detail:"Historic downtown break on the way to Pendleton."},
  {name:"Walla Walla",lat:46.0646,lon:-118.343,type:"Optional town stop",detail:"Only if AQI and temperature are comfortable."},
  {name:"Hood River Waterfront",lat:45.7086,lon:-121.5123,type:"Dog walk · river",detail:"Cooler waterfront option near Saturday lodging."},
  {name:"McMinnville",lat:45.2101,lon:-123.1987,type:"Cute town · local lunch",detail:"Optional Sunday stop en route to the coast."},
];

function distance(a:number,b:number,c:number,d:number){const r=3959,p=(x:number)=>x*Math.PI/180;const q=Math.sin(p(c-a)/2)**2+Math.cos(p(a))*Math.cos(p(c))*Math.sin(p(d-b)/2)**2;return 2*r*Math.asin(Math.sqrt(q));}

export default function Home(){
  const [tab,setTab]=useState<Tab>("home");
  const [checked,setChecked]=useState<string[]>(()=>{if(typeof window==="undefined")return [];try{return JSON.parse(localStorage.getItem("oregon-pack")||"[]");}catch{return [];}});
  const [nearby,setNearby]=useState<typeof stopSuggestions>([]);
  const [locationMsg,setLocationMsg]=useState("Use your phone location to rank planned road stops.");
  const total=useMemo(()=>Object.values(packing).flat().length,[]);
  const toggle=(item:string)=>{const next=checked.includes(item)?checked.filter(x=>x!==item):[...checked,item];setChecked(next);localStorage.setItem("oregon-pack",JSON.stringify(next));};
  const locate=()=>{if(!navigator.geolocation){setLocationMsg("Location is unavailable on this device.");return;}setLocationMsg("Finding the nearest planned stops…");navigator.geolocation.getCurrentPosition(p=>{const ranked=[...stopSuggestions].sort((x,y)=>distance(p.coords.latitude,p.coords.longitude,x.lat,x.lon)-distance(p.coords.latitude,p.coords.longitude,y.lat,y.lon));setNearby(ranked.slice(0,3));setLocationMsg("Nearest planned stops based on your current location:");},()=>setLocationMsg("Location permission was not granted. Use the route list instead."));};

  return <main className="appShell">
    <header className="appHero">
      <div className="appTop"><div><span>OREGON COAST / 2026</span><b>Brian · Miranda · Manny</b></div><div className="datePill">JUL 23 — AUG 3</div></div>
      <div className="heroCopy"><p>THE CURRENT BOOKED ROUTE</p><h1>High desert.<br/>River wind.<br/>Pacific coast.</h1><div className="routeLine">DENVER <i>→</i> OGDEN <i>→</i> PENDLETON <i>→</i> HOOD RIVER <i>→</i> DEPOE BAY <i>→</i> YAMHILL</div></div>
    </header>

    <nav className="tabs" aria-label="Trip sections">
      {([['home','Overview'],['itinerary','Itinerary'],['coast','Depoe Bay'],['packing','Packing'],['safety','Conditions']] as [Tab,string][]).map(([id,label])=><button key={id} onClick={()=>setTab(id)} className={tab===id?"active":""}>{label}</button>)}
    </nav>

    {tab==="home"&&<section className="panel overview">
      <div className="purpose"><span>THIS TAB ANSWERS</span><h2>What is booked, what matters, and what happens next?</h2><p>Use Overview for the trip’s confirmed framework. Detailed daily planning lives in Itinerary; coastal options live in Depoe Bay; operational decisions live in Conditions.</p></div>
      <div className="statusGrid">
        <article><small>FRI JUL 24</small><h3>MotoLodge</h3><p>Pendleton · booked</p><a href={links.motolodge} target="_blank">Hotel website ↗</a></article>
        <article><small>SAT JUL 25</small><h3>Hood River Hotel</h3><p>Historic downtown · booked</p><a href={links.hoodHotel} target="_blank">Hotel website ↗</a></article>
        <article><small>SUN–THU</small><h3>Depoe Bay rental</h3><p>4:00 check-in · 11:00 checkout</p></article>
        <article><small>THU–SUN</small><h3>Jake & Andrea</h3><p>Yamhill · confirmed</p></article>
      </div>
      <div className="notice"><b>Route change confirmed</b><p>Boise and Sisters are no longer part of the active itinerary. Tamolitch and Sahalie/Koosah are archived rather than presented as Sunday options.</p></div>
      <div className="quickGrid">
        <article><span>WORK</span><strong>Jul 27–28</strong><p>Protect two 6–8 hour blocks on local Pacific time.</p></article>
        <article><span>PTO</span><strong>6 days</strong><p>Jul 23, 24, 29, 30, 31 and Aug 3.</p></article>
        <article><span>DECISION RULE</span><strong>Comfort first</strong><p>Smoke, unhealthy AQI or stay-inside guidance replaces the destination.</p></article>
      </div>
    </section>}

    {tab==="itinerary"&&<section className="panel">
      <div className="purpose"><span>THIS TAB ANSWERS</span><h2>Where are we going each day, and how much driving is involved?</h2><p>This is the chronological source of truth. Open hotel and attraction links from the relevant day; use Conditions before committing to outdoor plans.</p></div>
      <div className="timeline">{days.map((d,i)=><article key={d.date} className={`tripDay ${d.tone}`}><div className="dayNum">{String(i+1).padStart(2,"0")}</div><div className="dayContent"><div className="dayHeader"><div><small>{d.date} · {d.logic}</small><h3>{d.place}</h3><b>{d.stay}</b></div><div className="drive"><span>DRIVING</span><strong>{d.drive}</strong></div></div><p>{d.plan}</p><em>{d.note}</em>{d.date.includes("Jul 24")&&<div className="dayLinks"><a href={links.motolodge} target="_blank">MotoLodge ↗</a><a href={links.shoshone} target="_blank">Shoshone Falls ↗</a><a href={links.pendleton} target="_blank">Pendleton ↗</a></div>}{d.date.includes("Jul 25")&&<div className="dayLinks"><a href={links.hoodHotel} target="_blank">Hood River Hotel ↗</a><a href={links.walla} target="_blank">Optional Walla Walla ↗</a><a href={links.hood} target="_blank">Hood River ↗</a></div>}</div></article>)}</div>
      <div className="locationTool"><div><span>LOCATION-AWARE ROAD STOPS</span><h3>What useful stop is closest right now?</h3><p>{locationMsg}</p><button onClick={locate}>Use my location</button></div>{nearby.length>0&&<div className="nearby">{nearby.map(s=><article key={s.name}><b>{s.name}</b><span>{s.type}</span><p>{s.detail}</p></article>)}</div>}</div>
    </section>}

    {tab==="coast"&&<section className="panel coastPanel">
      <div className="purpose"><span>THIS TAB ANSWERS</span><h2>How do we make the Depoe Bay stay feel planned without over-scheduling it?</h2><p>Morning walks are paired with workday-safe evening options. Choose by tides, wind, energy and Manny’s comfort rather than treating every suggestion as mandatory.</p></div>
      <div className="coastDays">
        <article><small>MONDAY · WORKDAY</small><h3>Fogarty morning / harbor evening</h3><ul><li><a href={links.fogarty} target="_blank">Fogarty Creek</a> for the early Manny walk.</li><li>Work 6–8 hours on Pacific time.</li><li>After work: Depoe Bay harbor and Boiler Bay viewpoint.</li><li>Takeout keeps the evening flexible.</li></ul></article>
        <article><small>TUESDAY · WORKDAY</small><h3>Gleneden morning / sunset evening</h3><ul><li><a href={links.gleneden} target="_blank">Gleneden Beach</a> for a different morning walk.</li><li>Second protected work block.</li><li>After work: <a href={links.punchbowl} target="_blank">Devil’s Punchbowl</a> or a short beach picnic.</li><li>Skip exposed viewpoints in high wind.</li></ul></article>
        <article><small>WEDNESDAY · PTO</small><h3>Full coast flex day</h3><ul><li>Choose north toward Lincoln City or south toward Newport.</li><li>Longer beach walk early.</li><li>Picnic when weather is better than patio weather.</li><li>Keep one unscheduled block for whale watching or downtime.</li></ul></article>
      </div>
      <h3 className="sectionTitle">Dog-compatible food strategy</h3>
      <div className="foodGrid"><a href={links.horn} target="_blank"><b>The Horn Public House</b><span>Local beer · confirm patio</span></a><a href={links.tidal} target="_blank"><b>Tidal Raves</b><span>Seafood · takeout-friendly fallback</span></a><a href={links.pelican} target="_blank"><b>Pelican Brewing Siletz Bay</b><span>Brewery · confirm patio seating</span></a></div>
      <div className="rental"><b>DEPOE BAY RENTAL</b><span>Address saved offline · Sun Jul 26, 4:00 PM → Thu Jul 30, 11:00 AM</span><p>Check the rental message for access, parking, Wi-Fi, pet payment and checkout tasks.</p></div>
    </section>}

    {tab==="packing"&&<section className="panel">
      <div className="purpose packHead"><div><span>THIS TAB ANSWERS</span><h2>What still needs to go in the car?</h2><p>Checks save on this device. Tap an item as it is packed—not merely gathered.</p></div><div className="progress"><strong>{checked.length}/{total}</strong><span>packed</span></div></div>
      <div className="progressBar"><i style={{width:`${checked.length/total*100}%`}}/></div>
      <div className="packGrid">{Object.entries(packing).map(([group,items])=><article key={group}><h3>{group}</h3>{items.map(item=><label key={item} className={checked.includes(item)?"done":""}><input type="checkbox" checked={checked.includes(item)} onChange={()=>toggle(item)}/><span>{item}</span></label>)}</article>)}</div>
      {checked.length>0&&<button className="reset" onClick={()=>{setChecked([]);localStorage.removeItem("oregon-pack")}}>Reset checklist</button>}
    </section>}

    {tab==="safety"&&<section className="panel">
      <div className="purpose"><span>THIS TAB ANSWERS</span><h2>Do conditions support the next destination—or should we replace it?</h2><p>NOAA covers weather and fire-weather risk. Pair it with AQI, official fire perimeters, evacuation information and road agencies before every major leg.</p></div>
      <div className="signals"><article className="go"><b>GO</b><h3>AQI 0–100</h3><p>Open roads, acceptable visibility and no nearby evacuation concern. Use normal heat precautions.</p></article><article className="review"><b>REVIEW</b><h3>AQI 101–150</h3><p>Compare with cleaner options. Shorten dog walks and remove optional outdoor detours.</p></article><article className="replace"><b>REPLACE</b><h3>AQI 151+ or warning</h3><p>Visible smoke, stay-inside guidance, evacuation notice, threatened access or official travel warning removes the destination.</p></article></div>
      <div className="sourceGrid"><a href={links.noaa} target="_blank"><b>NOAA / NWS</b><span>Forecasts, wind, thunderstorms, Red Flag Warnings</span></a><a href={links.airnow} target="_blank"><b>AirNow</b><span>Current AQI and smoke</span></a><a href={links.smoke} target="_blank"><b>Oregon Smoke</b><span>Advisories and monitor map</span></a><a href={links.fires} target="_blank"><b>Active Fire Map</b><span>Incident locations and perimeters</span></a><a href={links.evacuations} target="_blank"><b>Oregon Evacuations</b><span>Local emergency links</span></a><a href={links.tripcheck} target="_blank"><b>TripCheck</b><span>Oregon closures, incidents and cameras</span></a><a href={links.id511} target="_blank"><b>Idaho 511</b><span>Idaho road conditions</span></a><a href={links.wyroad} target="_blank"><b>WYDOT</b><span>Wyoming I-80 conditions</span></a></div>
      <div className="checkFlow"><b>CHECK THREE TIMES</b><span>Wednesday night: outbound overview</span><span>Friday morning: Pendleton corridor</span><span>Saturday morning: Walla Walla decision + Hood River AQI</span><span>Sunday morning: coast route</span></div>
    </section>}
    <footer className="appFooter"><b>OREGON COAST + YAMHILL</b><span>Current route · lodging updated Jul 22, 2026</span></footer>
  </main>;
}
