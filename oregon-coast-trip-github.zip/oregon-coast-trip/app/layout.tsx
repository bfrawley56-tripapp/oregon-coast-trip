import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Oregon Coast + Yamhill Trip",
  description: "Brian, Miranda and Manny's 2026 Oregon road-trip planner.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
